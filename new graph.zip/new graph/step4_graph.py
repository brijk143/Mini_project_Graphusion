import json
from pyvis.network import Network

# Function to read triplets from final_graph.jsonl file inside the 'output' folder
def read_triplets(file_path):
    triplets = []
    with open(file_path, 'r') as f:
        for line in f:
            # Parse each line as a JSON object
            data = json.loads(line.strip())
            subject = data.get('s')
            predicate = data.get('p')
            object_ = data.get('o')
            
            if subject and predicate and object_:
                triplets.append((subject, predicate, object_))
    return triplets

# Function to visualize the triplets interactively using Pyvis
def visualize_interactive_graph(triplets):
    # Create a Pyvis network
    net = Network(height="800px", width="100%", directed=True)

    # Add nodes and edges from the triplets
    for s, p, o in triplets:
        # Add nodes if they don't exist
        net.add_node(s, label=s, title=s)
        net.add_node(o, label=o, title=o)
        
        # Add edge with a label (predicate)
        net.add_edge(s, o, label=p)

    # Generate and save the interactive visualization as an HTML file
    # ...existing code...
    net.show("interactive_knowledge_graph.html", notebook=False)
# ...existing code...

# Main function to run the script
if __name__ == "__main__":
    # Set the path to the final_graph.jsonl file inside the 'output' folder
    file_path = 'output/final_graph.jsonl'

    # Read triplets from the file
    triplets = read_triplets(file_path)
    
    if triplets:
        visualize_interactive_graph(triplets)
    else:
        print("No triplets found in the file.")
