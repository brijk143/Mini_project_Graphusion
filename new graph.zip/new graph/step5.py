import json
import spacy
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import os
from dotenv import load_dotenv
import requests

# Load spaCy model and sentence transformer for semantic similarity
nlp = spacy.load("en_core_web_sm")
model = SentenceTransformer('all-MiniLM-L6-v2')

# Load environment variables
load_dotenv()
GOOGLE_API_KEY = os.getenv("GEMINI_API_KEY")
MODEL_NAME = "gemini-2.0-flash"

# Function to read triplets from final_graph.jsonl file inside the 'output' folder
def read_triplets(file_path):
    triplets = []
    with open(file_path, 'r') as f:
        for line in f:
            data = json.loads(line.strip())
            subject = data.get('s')
            predicate = data.get('p')
            object_ = data.get('o')
            if subject and predicate and object_:
                triplets.append((subject, predicate, object_))
    return triplets

# Semantic matching for triplets
def is_semantic_triplet_match(retrieved, expected, threshold=0.8):
    # Join triplet elements to form sentences
    retrieved_sentence = " ".join(retrieved)
    expected_sentence = " ".join(expected)
    embeddings = model.encode([retrieved_sentence, expected_sentence])
    score = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]
    return score >= threshold

# NLP-based function to parse the question and match triplets semantically
def retrieve_triplet(question, triplets):
    question_embedding = model.encode([question])
    best_score = 0
    best_triplet = (None, None, None)
    for s, p, o in triplets:
        triplet_sentence = f"{s} {p.replace('-', ' ')} {o}"
        triplet_embedding = model.encode([triplet_sentence])
        score = cosine_similarity([question_embedding[0]], [triplet_embedding[0]])[0][0]
        if score > best_score:
            best_score = score
            best_triplet = (s, p, o)
    if best_score > 0.6:
        return best_triplet
    else:
        return (None, None, None)

# Semantic matching for answers
def is_semantic_answer_match(generated_answer, expected_answer, threshold=0.8):
    embeddings = model.encode([generated_answer, expected_answer])
    score = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]
    return score >= threshold

# Generation function using Gemini API
def generate_answer(question, triplet):
    if None in triplet:
        context = "No relevant information found in the knowledge graph."
    else:
        context = f"Knowledge graph fact: {triplet[0]} {triplet[1]} {triplet[2]}"
    prompt = f"Question: {question}\nContext: {context}\nAnswer:"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL_NAME}:generateContent?key={GOOGLE_API_KEY}"
    headers = {"Content-Type": "application/json"}
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ]
    }
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        data = response.json()
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except Exception:
            return "Could not parse LLM response."
    else:
        return f"LLM API error: {response.status_code}"

# RAG pipeline evaluation (semantic matching for both retrieval and generation)
def evaluate_rag(test_file, triplets):
    total = 0
    correct_retrieval = 0
    correct_generation = 0
    with open(test_file, 'r') as f:
        for line in f:
            data = json.loads(line.strip())
            question = data['question']
            expected = data['expected']  # [subject, predicate, object]
            expected_answer = data.get('answer', None)  # Optional: reference answer
            retrieved = list(retrieve_triplet(question, triplets))
            generated_answer = generate_answer(question, retrieved)
            print(f"Q: {question}")
            print(f"Expected Triplet: {expected}")
            print(f"Retrieved Triplet: {retrieved}")
            print(f"Reference Answer: {expected_answer}")
            print(f"Generated Answer: {generated_answer}")
            # Semantic triplet matching
            if None not in retrieved and is_semantic_triplet_match(retrieved, expected):
                correct_retrieval += 1
            # Semantic answer matching
            if expected_answer is not None and is_semantic_answer_match(generated_answer, expected_answer):
                correct_generation += 1
            print()
            total += 1
    retrieval_accuracy = correct_retrieval / total if total > 0 else 0
    generation_accuracy = correct_generation / total if total > 0 else 0
    print(f"Total questions: {total}")
    print(f"Correct triplet retrievals : {correct_retrieval}")
    print(f"Retrieval Accuracy : {retrieval_accuracy:.2f}")
    if total > 0:
        print(f"Correct generated answers : {correct_generation}")
        print(f"Generation Accuracy : {generation_accuracy:.2f}")

if __name__ == "__main__":
    file_path = 'output/final_graph.jsonl'
    triplets = read_triplets(file_path)
    test_file = 'test_questions.jsonl'
    evaluate_rag(test_file, triplets)