# import os
# import sys
# import json
# import logging
# from collections import Counter
# from dotenv import load_dotenv
# from langchain_core.prompts import ChatPromptTemplate
# from langchain_google_genai import ChatGoogleGenerativeAI
# from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
# from tqdm import tqdm

# load_dotenv()
# google_api_key = os.getenv("GOOGLE_API_KEY")
# if not google_api_key:
#     sys.exit("ERROR: Please set the GOOGLE_API_KEY environment variable (or add it to a .env file).")
# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s %(levelname)s: %(message)s"
# )

# OUTPUT_BASE_DIR = "output"

# INPUT_CONCEPTS_PATH  = os.path.join(OUTPUT_BASE_DIR, "seed_entities.txt") 
# INPUT_ABSTRACTS_PATH = "abstract.txt"                             
# OUTPUT_FILE          = os.path.join(OUTPUT_BASE_DIR, "candidate_triples.jsonl")
# PROMPT_PATH          = os.path.join("prompts", "prompts_step2.txt") 
# MODEL_NAME           = "gemini-2.0-flash"
# MAX_INPUT_CHAR       = 10000  # max characters of content per API call

# RELATION_DEFS = {
#     "Compare": {
#         "label": "Compare",
#         "description": "Represents a relationship between two or more entities where a comparison is being made. For example, \"A is larger than B\" or \"X is more efficient than Y.\" (Non-directional)"
#     },
#     "Part-of": {
#         "label": "Part-of",
#         "description": "Denotes a relationship where one entity is a constituent or component of another. For instance, \"Wheel is a part of a Car.\" (Directional)"
#     },
#     "Conjunction": {
#         "label": "Conjunction",
#         "description": "Indicates a logical or semantic relationship where two or more entities are connected to form a group or composite idea. For example, \"Salt and Pepper.\" (Non-directional)"
#     },
#     "Evaluate-for": {
#         "label": "Evaluate-for",
#         "description": "Represents an evaluative relationship where one entity is assessed in the context of another. For example, \"A tool is evaluated for its effectiveness.\" (Directional)"
#     },
#     "Is-a-Prerequisite-of": {
#         "label": "Is-a-Prerequisite-of",
#         "description": "This dual-purpose relationship implies that one entity is either a characteristic of another or a required precursor for another. For instance, \"The ability to code is a prerequisite of software development.\" (Directional)"
#     },
#     "Used-for": {
#         "label": "Used-for",
#         "description": "Denotes a functional relationship where one entity is utilized in accomplishing or facilitating the other. For example, \"A hammer is used for driving nails.\" (Directional)"
#     },
#     "Hyponym-Of": {
#         "label": "Hyponym-Of",
#         "description": "Establishes a hierarchical relationship where one entity is a more specific version or subtype of another. For instance, \"A Sedan is a hyponym of a Car.\" (Directional)"
#     },
#     "Leads-to": {
#         "label": "Leads-to",
#         "description": "Represents a relationship where one concept causes or triggers the existence or development of another. For example, \"Recursion leads to function calls.\" (Directional)"
#     },
#     "Is-similar-to": {
#         "label": "Is-similar-to",
#         "description": "Denotes a relationship where two concepts share similarities but are not identical. For example, \"Stack is similar to Queue in terms of function management.\" (Non-directional)"
#     },
#     "Has-property": {
#         "label": "Has-property",
#         "description": "Indicates that one concept possesses certain attributes or features. For example, \"Binary Tree has the property of having at most two children.\" (Directional)"
#     },
#     "Has-function": {
#         "label": "Has-function",
#         "description": "Denotes the functional role or purpose of a concept. For example, \"Heap has the function of implementing priority queues.\" (Directional)"
#     },
#     "Is-implemented-by": {
#         "label": "Is-implemented-by",
#         "description": "Represents a relationship where one concept is implemented or realized by another. For example, \"QuickSort is implemented by recursive partitioning.\" (Directional)"
#     },
#     "Depends-on": {
#         "label": "Depends-on",
#         "description": "Represents a relationship where one concept relies on or is dependent on another. For example, \"Doubly Linked List depends on having two pointers.\" (Directional)"
#     }
# }


# def load_abstracts():
#     """Load abstracts/content from file"""
#     if not os.path.exists(INPUT_ABSTRACTS_PATH):
#         logging.error(f"Abstracts file not found: {INPUT_ABSTRACTS_PATH}")
#         logging.info("Please create an abstracts file with the content to analyze")
#         return None
    
#     with open(INPUT_ABSTRACTS_PATH, 'r', encoding='utf-8') as f:
#         content = f.read().strip()
    
#     if not content:
#         logging.error("Abstracts file is empty")
#         return None
    
#     logging.info(f"Loaded {len(content)} characters from abstracts file")
#     return content

# def chunk_content(content, max_chars):
#     """Split content into chunks that fit within the character limit"""
#     chunks = []
#     words = content.split()
#     current_chunk = []
#     current_length = 0
    
#     for word in words:
#         word_length = len(word) + 1  
#         if current_length + word_length > max_chars and current_chunk:
#             chunks.append(' '.join(current_chunk))
#             current_chunk = [word]
#             current_length = word_length
#         else:
#             current_chunk.append(word)
#             current_length += word_length
    
#     if current_chunk:
#         chunks.append(' '.join(current_chunk))
    
#     return chunks

# def parse_triplet_output(text):
#     """Parse the triplet output format: (concept, relation, concept)(concept, relation, concept)"""
#     triplets = []
#     if not text or text.lower().strip() == "none":
#         return triplets
    
#     # Try to parse as JSON first (in case model returns JSON)
#     try:
#         json_data = json.loads(text)
#         if isinstance(json_data, list):
#             for item in json_data:
#                 if isinstance(item, dict) and 's' in item and 'p' in item and 'o' in item:
#                     triplets.append({
#                         's': item['s'],
#                         'p': item['p'],
#                         'o': item['o']
#                     })
#         return triplets
#     except json.JSONDecodeError:
#         pass
#     # Fallback to regex parsing
#     import re
#     pattern = r'\(([^,]+),\s*([^,]+),\s*([^)]+)\)'
#     matches = re.findall(pattern, text)
    
#     for match in matches:
#         head, relation, tail = [item.strip() for item in match]
#         triplets.append({
#             's': head,
#             'p': relation,
#             'o': tail
#         })
    
#     return triplets

# def extract_candidate_triples():
#     logging.info("Starting Step 2: Candidate Triple Extraction with Gemini API")

#     model = ChatGoogleGenerativeAI(
#         model=MODEL_NAME,
#         temperature=0.1,
#         google_api_key=google_api_key
#     )

#     if not os.path.exists(INPUT_CONCEPTS_PATH):
#         logging.error(f"Input concepts file not found: {INPUT_CONCEPTS_PATH}")
#         logging.info("Please ensure step1.py has run successfully to generate this file.")
#         return

#     with open(INPUT_CONCEPTS_PATH, 'r', encoding='utf-8') as f:
#         query_concepts = [line.strip().strip('"') for line in f if line.strip()]
#     all_content = load_abstracts()
#     if not all_content:
#         return
    
#     if not os.path.exists(PROMPT_PATH):
#         logging.error(f"Prompt file not found: {PROMPT_PATH}")
#         logging.info("Please ensure 'prompts/prompts_step2.txt' exists.")
#         return

#     prompt_txt = open(PROMPT_PATH, 'r', encoding='utf-8').read()
#     prompt_template = ChatPromptTemplate.from_messages([
#         ("system", "You are a knowledge graph builder using Google Gemini."),
#         ("user", prompt_txt)
#     ])

#     os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

#     extracted_counts = []
    
#     with open(OUTPUT_FILE, 'w', encoding='utf-8') as outp:
#         for query_concept in tqdm(query_concepts, desc="Processing query concepts"):
#             # Chunk the content to fit within limits
#             content_chunks = chunk_content(all_content, MAX_INPUT_CHAR)
            
#             for i, content_chunk in enumerate(content_chunks):
#                 relation_defs_text = "\n".join(
#                     f"{r}: {RELATION_DEFS[r]['description']}" for r in RELATION_DEFS
#                 )

#                 # Fill in the prompt with the current query concept and content chunk
#                 invocation = prompt_template.invoke({
#                     "query_concept": query_concept,            
#                     "content": content_chunk,                  
#                     "relation_definitions": relation_defs_text
#                 })

#                 # DEBUG: print out exactly what goes to Gemini (only for first concept, first chunk)
#                 if query_concept == query_concepts[0] and i == 0:
#                     print("\n=== Filled Prompt (First Query Concept, First Chunk) ===")
            
#                 try:
#                     response = model.invoke(invocation)
#                     text = getattr(response, "content", "").strip()
#                 except Exception as e:
#                     logging.error(f"Error calling Gemini for concept '{query_concept}', chunk {i}: {e}")
#                     continue

#                 if not text or text.lower() == "none":
#                     continue

#                 # Parse the triplet output
#                 triplets = parse_triplet_output(text)
                
#                 if not triplets:
#                     logging.warning(f"No valid triplets parsed for '{query_concept}', chunk {i}: {text}")
#                     continue

#                 # Write each extracted triple
#                 for triplet in triplets:
#                     rel = triplet.get('p')
#                     if rel not in RELATION_DEFS:
#                         logging.warning(f"Unknown relation '{rel}' - skipping triplet")
#                         continue
                    
#                     # Remove metadata fields before writing
#                     triplet.pop('query_concept', None)
#                     triplet.pop('content_chunk', None)
                    
#                     outp.write(json.dumps(triplet) + "\n")
#                     extracted_counts.append(rel)

#     logging.info(f"Extracted {len(extracted_counts)} triples to {OUTPUT_FILE}")
#     logging.info(f"Triple counts by relation: {Counter(extracted_counts)}")


# if __name__ == "__main__":
#     extract_candidate_triples()






import os
import sys
import json
import logging
from collections import Counter
from dotenv import load_dotenv
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from tqdm import tqdm
import re

load_dotenv()
google_api_key = os.getenv("GOOGLE_API_KEY")
if not google_api_key:
    sys.exit("ERROR: Please set the GOOGLE_API_KEY environment variable (or add it to a .env file).")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s: %(message)s"
)

OUTPUT_BASE_DIR = "output"

INPUT_CONCEPTS_PATH  = os.path.join(OUTPUT_BASE_DIR, "seed_entities.txt") 
INPUT_ABSTRACTS_PATH = "abstract.txt"                             
OUTPUT_FILE          = os.path.join(OUTPUT_BASE_DIR, "candidate_triples.jsonl")
PROMPT_PATH          = os.path.join("prompts", "prompts_step2.txt") 
MODEL_NAME           = "gemini-2.0-flash"
MAX_INPUT_CHAR       = 10000  # max characters of content per API call

RELATION_DEFS = {
    "Compare": {"label": "Compare"},
    "Part-of": {"label": "Part-of"},
    "Conjunction": {"label": "Conjunction"},
    "Evaluate-for": {"label": "Evaluate-for"},
    "Is-a-Prerequisite-of": {"label": "Is-a-Prerequisite-of"},
    "Used-for": {"label": "Used-for"},
    "Hyponym-Of": {"label": "Hyponym-Of"},
    "Leads-to": {"label": "Leads-to"},
    "Is-similar-to": {"label": "Is-similar-to"},
    "Has-property": {"label": "Has-property"},
    "Has-function": {"label": "Has-function"},
    "Is-implemented-by": {"label": "Is-implemented-by"},
    "Depends-on": {"label": "Depends-on"}
}


# -------------------
# File + content utils
# -------------------
def load_abstracts():
    """Load abstracts/content from file"""
    if not os.path.exists(INPUT_ABSTRACTS_PATH):
        logging.error(f"Abstracts file not found: {INPUT_ABSTRACTS_PATH}")
        logging.info("Please create an abstracts file with the content to analyze")
        return None
    
    with open(INPUT_ABSTRACTS_PATH, 'r', encoding='utf-8') as f:
        content = f.read().strip()
    
    if not content:
        logging.error("Abstracts file is empty")
        return None
    
    logging.info(f"Loaded {len(content)} characters from abstracts file")
    return content


def chunk_content(content, max_chars):
    """Split content into chunks that fit within the character limit"""
    chunks = []
    words = content.split()
    current_chunk = []
    current_length = 0
    
    for word in words:
        word_length = len(word) + 1  
        if current_length + word_length > max_chars and current_chunk:
            chunks.append(' '.join(current_chunk))
            current_chunk = [word]
            current_length = word_length
        else:
            current_chunk.append(word)
            current_length += word_length
    
    if current_chunk:
        chunks.append(' '.join(current_chunk))
    
    return chunks


# -------------------
# Triplet parsing utils
# -------------------
def normalize_relation(rel):
    """Normalize relation casing and enforce predefined schema."""
    rel = rel.strip().replace(" ", "-").replace("_", "-").title()

    mapping = {
        "Is-A-Prerequisite-Of": "Is-a-Prerequisite-of",
        "Used-For": "Used-for",
        "Part-Of": "Part-of",
        "Hyponym-Of": "Hyponym-Of",
        "Leads-To": "Leads-to",
        "Is-Similar-To": "Is-similar-to",
        "Has-Property": "Has-property",
        "Has-Function": "Has-function",
        "Is-Implemented-By": "Is-implemented-by",
        "Depends-On": "Depends-on",
        "Compare": "Compare",
        "Conjunction": "Conjunction",
        "Evaluate-For": "Evaluate-for"
    }

    return mapping.get(rel, rel)


def parse_triplet_output(text):
    """Parse Gemini output into structured triplets (s, p, o)."""

    triplets = []

    if not text or text.strip().lower() == "none":
        return triplets

    # 1. Try JSON parsing first
    try:
        json_data = json.loads(text)
        if isinstance(json_data, list):
            for item in json_data:
                if isinstance(item, dict) and 's' in item and 'p' in item and 'o' in item:
                    triplets.append({
                        's': item['s'].strip(),
                        'p': normalize_relation(item['p']),
                        'o': item['o'].strip()
                    })
            return triplets
    except json.JSONDecodeError:
        pass

    # 2. Regex parsing for (head, relation, tail)
    pattern = r'\(([^,]+?),\s*([^,]+?),\s*([^)]+?)\)'
    matches = re.findall(pattern, text, flags=re.DOTALL)

    for match in matches:
        head, relation, tail = [item.strip() for item in match]
        triplets.append({
            's': head,
            'p': normalize_relation(relation),
            'o': tail
        })

    return triplets


# -------------------
# Extraction main
# -------------------
def extract_candidate_triples():
    logging.info("Starting Step 2: Candidate Triple Extraction with Gemini API")

    model = ChatGoogleGenerativeAI(
        model=MODEL_NAME,
        temperature=0.1,
        google_api_key=google_api_key
    )

    if not os.path.exists(INPUT_CONCEPTS_PATH):
        logging.error(f"Input concepts file not found: {INPUT_CONCEPTS_PATH}")
        logging.info("Please ensure step1.py has run successfully to generate this file.")
        return

    with open(INPUT_CONCEPTS_PATH, 'r', encoding='utf-8') as f:
        query_concepts = [line.strip().strip('"') for line in f if line.strip()]
    all_content = load_abstracts()
    if not all_content:
        return
    
    if not os.path.exists(PROMPT_PATH):
        logging.error(f"Prompt file not found: {PROMPT_PATH}")
        logging.info("Please ensure 'prompts/prompts_step2.txt' exists.")
        return

    prompt_txt = open(PROMPT_PATH, 'r', encoding='utf-8').read()
    prompt_template = ChatPromptTemplate.from_messages([
        ("system", "You are a knowledge graph builder using Google Gemini."),
        ("user", prompt_txt)
    ])

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

    extracted_counts = []
    
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as outp:
        for query_concept in tqdm(query_concepts, desc="Processing query concepts"):
            content_chunks = chunk_content(all_content, MAX_INPUT_CHAR)
            
            for i, content_chunk in enumerate(content_chunks):
                relation_defs_text = "\n".join(
                    f"{r}: {RELATION_DEFS[r]['label']}" for r in RELATION_DEFS
                )

                invocation = prompt_template.invoke({
                    "query_concept": query_concept,            
                    "content": content_chunk,                  
                    "relation_definitions": relation_defs_text
                })

                # Debug for first concept
                if query_concept == query_concepts[0] and i == 0:
                    print("\n=== Filled Prompt (First Query Concept, First Chunk) ===")
                    print(invocation)

                try:
                    response = model.invoke(invocation)
                    text = getattr(response, "content", "").strip()
                except Exception as e:
                    logging.error(f"Error calling Gemini for concept '{query_concept}', chunk {i}: {e}")
                    continue

                if not text or text.lower() == "none":
                    continue

                # Parse triplets
                triplets = parse_triplet_output(text)
                
                if not triplets:
                    logging.warning(f"No valid triplets parsed for '{query_concept}', chunk {i}. Raw output:\n{text}\n")
                    continue

                for triplet in triplets:
                    rel = triplet.get('p')
                    if rel not in RELATION_DEFS:
                        logging.warning(f"Unknown relation '{rel}' - skipping triplet. Raw triplet: {triplet}")
                        continue
                    
                    triplet.pop('query_concept', None)
                    triplet.pop('content_chunk', None)
                    
                    outp.write(json.dumps(triplet) + "\n")
                    extracted_counts.append(rel)

    logging.info(f"Extracted {len(extracted_counts)} triples to {OUTPUT_FILE}")
    logging.info(f"Triple counts by relation: {Counter(extracted_counts)}")


if __name__ == "__main__":
    extract_candidate_triples()
